"use client";

import { CalendarDays, Users, QrCode, TrendingUp, ArrowUpRight } from "lucide-react";
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell 
} from "recharts";

// Data Dummy untuk Grafik Tren
const trendData = [
  { day: "Mon", count: 45 },
  { day: "Tue", count: 52 },
  { day: "Wed", count: 38 },
  { day: "Thu", count: 65 },
  { day: "Fri", count: 48 },
  { day: "Sat", count: 20 },
  { day: "Sun", count: 15 },
];

// Data Dummy untuk Pie Chart (Status Kehadiran)
const presenceData = [
  { name: "Hadir", value: 85, color: "#3b82f6" },
  { name: "Izin", value: 10, color: "#f59e0b" },
  { name: "Sakit", value: 5, color: "#ef4444" },
];

export default function DashboardPage() {
  return (
    <div className="space-y-8 text-slate-200 p-2">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-black tracking-tighter text-white">INSIGHTS</h1>
        <p className="text-slate-500 text-sm font-medium">Monitoring real-time aktivitas absensi.</p>
      </div>

      {/* STATS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: "Total Rapat", value: "12", icon: CalendarDays, trend: "+2" },
          { title: "Rapat Hari Ini", value: "2", icon: CalendarDays, trend: "Stable" },
          { title: "Total Peserta", value: "128", icon: Users, trend: "+12%" },
          { title: "Scan Hari Ini", value: "30", icon: QrCode, trend: "+5" },
        ].map((item, i) => (
          <div key={i} className="group bg-slate-900/40 border border-slate-800 p-5 rounded-2xl hover:border-blue-500/50 transition-all duration-500">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-slate-800 rounded-lg text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <item.icon size={20} />
              </div>
              <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                <TrendingUp size={10}/> {item.trend}
              </span>
            </div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">{item.title}</p>
            <p className="text-3xl font-black text-white mt-1">{item.value}</p>
          </div>
        ))}
      </div>

      {/* CHARTS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Tren Absensi (Area Chart) */}
        <div className="lg:col-span-2 bg-slate-900/40 border border-slate-800 rounded-3xl p-6">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-sm font-black uppercase tracking-[3px] text-slate-400">Activity Trend</h3>
            <button className="text-blue-500 text-xs font-bold flex items-center gap-1 hover:underline">
              View Details <ArrowUpRight size={14}/>
            </button>
          </div>
          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis 
                  dataKey="day" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#64748b', fontSize: 10, fontWeight: 'bold'}}
                  dy={10}
                />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px'}}
                  itemStyle={{color: '#fff', fontSize: '12px', fontWeight: 'bold'}}
                />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorCount)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Komposisi (Pie Chart) */}
        <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 flex flex-col">
          <h3 className="text-sm font-black uppercase tracking-[3px] text-slate-400 mb-8">Attendance Share</h3>
          <div className="flex-1 h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={presenceData}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {presenceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3 mt-4">
            {presenceData.map((item) => (
              <div key={item.name} className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{backgroundColor: item.color}} />
                  <span className="text-xs font-bold text-slate-400">{item.name}</span>
                </div>
                <span className="text-xs font-black">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

     

    </div>
  );
}