import Sidebar from "@/app/src/components/sidebar";
import Topbar from "@/app/src/components/Topbar";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen bg-slate-900 text-slate-100">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        <Topbar />
        <main className="p-10 space-y-8">
          {children}
        </main>
      </div>
    </div>
  );
}
