"use client";

import { useState } from "react";
import { 
  Check, X, Clock, Calendar, 
  Search, CheckCircle2, AlertCircle, 
  ChevronRight, FileText, User
} from "lucide-react";

const initialRequests = [
  {
    id: "1",
    name: "Andi Wijaya",
    avatar: "AW",
    type: "Sakit",
    date: "20 Jan 2025",
    submittedAt: "1 jam lalu",
    reason: "Demam tinggi dan butuh istirahat total sesuai anjuran dokter.",
    status: "pending",
  },
  {
    id: "2",
    name: "Siti Aminah",
    avatar: "SA",
    type: "Cuti",
    date: "22 - 25 Jan 2025",
    submittedAt: "3 jam lalu",
    reason: "Urusan keluarga mendadak di luar kota (pernikahan saudara).",
    status: "approved",
  },
  {
    id: "3",
    name: "Budi Santoso",
    avatar: "BS",
    type: "Izin",
    date: "21 Jan 2025",
    submittedAt: "5 jam lalu",
    reason: "Keperluan perpanjangan SIM di Satpas.",
    status: "rejected",
  },
];

export default function PermissionsPage() {
  const [requests, setRequests] = useState(initialRequests);
  const [activeFilter, setActiveFilter] = useState("all");

  const handleAction = (id: string, newStatus: "approved" | "rejected") => {
    setRequests(requests.map(req => req.id === id ? { ...req, status: newStatus } : req));
  };

  const filteredRequests = requests.filter(req => 
    activeFilter === "all" ? true : req.status === activeFilter
  );

  return (
    <div className="space-y-6 text-white max-w-6xl mx-auto p-2">
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Persetujuan Izin</h1>
          <p className="text-slate-400 text-xs">Kelola permohonan ketidakhadiran karyawan.</p>
        </div>
        
        <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-xl w-fit">
          {["all", "pending", "approved", "rejected"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveFilter(tab)}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all ${
                activeFilter === tab ? "bg-blue-600 text-white" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* STATS WIDGETS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatWidget label="Total" value={requests.length} icon={<FileText size={18}/>} color="blue" />
        <StatWidget label="Pending" value={requests.filter(r => r.status === "pending").length} icon={<Clock size={18}/>} color="orange" />
        <StatWidget label="Disetujui" value={requests.filter(r => r.status === "approved").length} icon={<CheckCircle2 size={18}/>} color="emerald" />
        <StatWidget label="Ditolak" value={requests.filter(r => r.status === "rejected").length} icon={<AlertCircle size={18}/>} color="red" />
      </div>

      {/* SEARCH */}
      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
        <input 
          type="text" 
          placeholder="Cari karyawan..."
          className="w-full bg-slate-800/40 border border-slate-700/50 rounded-xl py-3 pl-12 pr-4 outline-none focus:border-blue-500/50 transition text-sm"
        />
      </div>

      {/* LIST CONTENT */}
      <div className="space-y-3">
        {filteredRequests.map((req) => (
          <div 
            key={req.id} 
            className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 hover:bg-slate-800/80 transition-all group"
          >
            <div className="flex items-center justify-between gap-4">
              
              {/* 1. NAMA & INFO (KIRI) */}
              <div className="flex items-center gap-4 w-[280px] shrink-0">
                <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center text-sm font-bold text-blue-400 shrink-0">
                  {req.avatar}
                </div>
                <div className="overflow-hidden">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-100 truncate text-sm">{req.name}</h3>
                    <span className="px-1.5 py-0.5 rounded bg-slate-900 text-[9px] font-black uppercase border border-slate-700 text-slate-400">
                      {req.type}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-slate-500 mt-1">
                    <span className="flex items-center gap-1"><Calendar size={12}/> {req.date}</span>
                    <span className="flex items-center gap-1"><Clock size={12}/> {req.submittedAt}</span>
                  </div>
                </div>
              </div>

              {/* 2. ALASAN (TENGAH - FLEX GROW) */}
              <div className="flex-1 hidden md:block">
                <div className="bg-slate-900/30 border border-slate-700/30 rounded-lg px-4 py-2 text-xs text-slate-400 italic line-clamp-1 border-dashed">
                  "{req.reason}"
                </div>
              </div>

              {/* 3. AKSI & STATUS (KANAN SEMUA) */}
              <div className="flex items-center gap-3 shrink-0 ml-auto">
                {req.status === "pending" ? (
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleAction(req.id, "rejected")}
                      className="p-2 rounded-lg border border-slate-700/50 text-slate-500 hover:text-red-500 hover:bg-red-500/10 transition-all"
                      title="Tolak"
                    >
                      <X size={18} />
                    </button>
                    <button 
                      onClick={() => handleAction(req.id, "approved")}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] transition-all"
                    >
                      <Check size={14} /> Setujui
                    </button>
                  </div>
                ) : (
                  <div className={`px-3 py-1 rounded-lg border text-[9px] font-black uppercase tracking-[2px] ${
                    req.status === 'approved' 
                    ? 'border-emerald-500/20 bg-emerald-500/5 text-emerald-500' 
                    : 'border-red-500/20 bg-red-500/5 text-red-500'
                  }`}>
                    {req.status}
                  </div>
                )}
                
                <div className="h-8 w-[1px] bg-slate-700/50 mx-1 hidden sm:block"></div>
                
                <button className="p-2 text-slate-600 hover:text-white transition group-hover:translate-x-1 duration-200">
                  <ChevronRight size={18} />
                </button>
              </div>

            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* COMPONENT WIDGET */
function StatWidget({ label, value, icon, color }: { label: string; value: number; icon: React.ReactNode; color: string }) {
  const colors: Record<string, string> = {
    blue: "text-blue-400 border-blue-400/20",
    orange: "text-orange-400 border-orange-400/20",
    emerald: "text-emerald-400 border-emerald-400/20",
    red: "text-red-400 border-red-400/20",
  };

  return (
    <div className={`p-3 rounded-xl border bg-slate-800/30 flex items-center gap-3 ${colors[color]}`}>
      <div className="p-2 bg-slate-900 rounded-lg shrink-0">{icon}</div>
      <div>
        <p className="text-[9px] font-black uppercase tracking-widest opacity-60 mb-0.5">{label}</p>
        <p className="text-lg font-bold text-white leading-none">{value}</p>
      </div>
    </div>
  );
}