"use client";

import {
  CalendarDays,
  Clock,
  MapPin,
  Users,
  Download,
  ArrowLeft,
} from "lucide-react";
import Link from "next/link";
import { QRCodeSVG } from "qrcode.react"; // Pastikan sudah install qrcode.react

export default function EventDetailPage() {
  const event = {
    id: "1",
    title: "Rapat Evaluasi Bulanan",
    date: "20 Januari 2025",
    time: "09:00 - 11:00",
    location: "Ruang Meeting Lt.2",
    participants: 32,
    description: "Rapat evaluasi kinerja bulanan untuk membahas capaian dan rencana bulan berikutnya.",
    status: "active",
  };

  // URL yang akan masuk ke dalam QR Code
  const qrUrl = `https://absensi-rapat.com/scan?event=${event.id}`;

  const downloadQR = () => {
    const svg = document.getElementById("qr-code-download");
    if (svg) {
        const svgData = new XMLSerializer().serializeToString(svg);
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        const img = new Image();
        img.onload = () => {
          canvas.width = img.width;
          canvas.height = img.height;
          ctx?.drawImage(img, 0, 0);
          const pngFile = canvas.toDataURL("image/png");
          const downloadLink = document.createElement("a");
          downloadLink.download = `QR-${event.title}.png`;
          downloadLink.href = pngFile;
          downloadLink.click();
        };
        img.src = "data:image/svg+xml;base64," + btoa(svgData);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl text-white">
      {/* BACK & HEADER */}
      <div className="flex flex-col gap-4">
        <Link href="/dashboard/admin/events" className="text-slate-400 hover:text-white flex items-center gap-2 text-sm transition w-fit">
            <ArrowLeft size={16}/> Kembali
        </Link>
        <div className="flex items-start justify-between">
            <div>
                <h1 className="text-2xl font-semibold">{event.title}</h1>
                <p className="text-slate-400 text-sm mt-1">Detail event & absensi rapat</p>
            </div>
            <span className={`text-xs px-4 py-1.5 rounded-full font-medium ${
                event.status === "active" ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-600/20 text-slate-400"
            }`}>
                {event.status === "active" ? "Aktif" : "Selesai"}
            </span>
        </div>
      </div>

      {/* INFO GRID */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <InfoItem icon={<CalendarDays size={18} />} label="Tanggal" value={event.date} />
        <InfoItem icon={<Clock size={18} />} label="Waktu" value={event.time} />
        <InfoItem icon={<MapPin size={18} />} label="Lokasi" value={event.location} />
        <InfoItem icon={<Users size={18} />} label="Peserta" value={`${event.participants} Orang`} />
      </div>

      {/* DESKRIPSI */}
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6">
        <h3 className="font-semibold mb-2">Deskripsi Rapat</h3>
        <p className="text-sm text-slate-300 leading-relaxed">{event.description}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* QR GENERATOR */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6 flex flex-col items-center justify-center">
          <div className="p-4 bg-white rounded-2xl shadow-xl">
            <QRCodeSVG 
                id="qr-code-download"
                value={qrUrl} 
                size={180} 
                level="H"
                includeMargin={false}
            />
          </div>
          <p className="text-sm text-slate-400 mt-5 text-center px-6">
            Tampilkan QR ini di layar proyektor agar peserta bisa melakukan scan.
          </p>
          <button 
            onClick={downloadQR}
            className="mt-6 flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 transition text-sm font-medium"
          >
            <Download size={16} /> Download QR Image
          </button>
        </div>

        {/* STAT ABSENSI */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6 space-y-5">
          <h3 className="font-semibold border-b border-slate-700 pb-3">Statistik Absensi</h3>
          <div className="space-y-4">
            <StatRow label="Total Peserta Terdaftar" value="32" />
            <StatRow label="Hadir Tepat Waktu" value="24" />
            <StatRow label="Hadir Terlambat" value="3" />
            <StatRow label="Belum Absensi" value="5" />
          </div>
          <div className="pt-4">
            <button className="w-full px-4 py-3 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition text-sm font-bold border border-red-500/20">
                Tutup Sesi Absensi
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 flex items-center gap-4">
      <div className="text-blue-400 bg-blue-400/10 p-2 rounded-lg">{icon}</div>
      <div>
        <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">{label}</p>
        <p className="text-sm font-medium">{value}</p>
      </div>
    </div>
  );
}

function StatRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center text-sm">
      <span className="text-slate-400">{label}</span>
      <span className="font-mono font-bold bg-slate-900 px-3 py-1 rounded-lg text-blue-400">{value}</span>
    </div>
  );
}