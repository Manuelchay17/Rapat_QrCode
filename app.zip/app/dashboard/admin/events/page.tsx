"use client";

import { CalendarDays, MapPin, QrCode, Users, X, AlignLeft, ChevronRight } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

const eventsData = [
  {
    id: "1",
    title: "Rapat Evaluasi Bulanan",
    date: "20 Januari 2025",
    time: "09:00 - 11:00",
    location: "Ruang Meeting Lt.2",
    participants: 32,
    status: "active",
    description: "Membahas pencapaian KPI tiap departemen dan hambatan selama bulan Januari.",
  },
  {
    id: "2",
    title: "Briefing Proyek Aplikasi",
    date: "18 Januari 2025",
    time: "13:00 - 14:30",
    location: "Ruang IT",
    participants: 18,
    status: "done",
    description: "Koordinasi teknis tim developer dan desain untuk peluncuran fitur absensi QR.",
  },
];

export default function EventsPage() {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="space-y-8 relative text-white">
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Event Rapat</h1>
          <p className="text-slate-400 text-sm">Kelola rapat dan absensi peserta</p>
        </div>

        <button 
          onClick={() => setShowModal(true)}
          className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 transition text-sm font-medium"
        >
          + Buat Event
        </button>
      </div>

      {/* EVENT GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {eventsData.map((event) => (
          <Link 
            key={event.id} 
            href={`/dashboard/admin/events/${event.id}`} // Link menuju folder [id]
            className="group block"
          >
            <div className="rounded-2xl bg-slate-800 border border-slate-700 p-6 space-y-5 group-hover:border-blue-600 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10 h-full flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between border-b pb-3 border-slate-700 mb-4">
                  <h2 className="font-semibold text-lg leading-snug group-hover:text-blue-400 transition">
                    {event.title}
                  </h2>
                  <span className={`text-[10px] px-2 py-1 rounded-full font-medium ${
                      event.status === "active" ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-600/20 text-slate-400"
                  }`}>
                    {event.status === "active" ? "Aktif" : "Selesai"}
                  </span>
                </div>

                {/* DESKRIPSI */}
                <div className="flex gap-2 mb-4">
               
                  <p className="text-sm text-slate-400 line-clamp-2 italic tracking-wide">
                    {event.description}
                  </p>
                </div>

                {/* INFO */}
                <div className="space-y-3 text-sm text-slate-300">
                  <div className="flex items-center gap-3">
                    <CalendarDays size={16} className="text-slate-500" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin size={16} className="text-slate-500" />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Users size={16} className="text-slate-500" />
                    <span>{event.participants} Peserta</span>
                  </div>
                </div>
              </div>

              {/* ACTION FOOTER */}
              <div className="pt-4 border-t border-slate-700 flex justify-between items-center">
                <div className="flex items-center gap-2 text-sm text-blue-400 font-medium">
                  <QrCode size={16} />
                  QR Absensi
                </div>
                <div className="text-slate-500 group-hover:text-white transition flex items-center gap-1 text-sm">
                  Detail <ChevronRight size={14} />
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* MODAL BUAT EVENT (Sama seperti sebelumnya) */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 border border-slate-700 w-full max-w-md rounded-2xl p-6 space-y-4 shadow-2xl animate-in zoom-in duration-200">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Buat Rapat Baru</h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white"><X size={20}/></button>
            </div>
            <div className="space-y-3">
              <input type="text" placeholder="Nama Rapat" className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-600 text-sm" />
              <textarea placeholder="Deskripsi Singkat..." rows={3} className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-600 text-sm resize-none"></textarea>
              <div className="grid grid-cols-2 gap-3">
                <input type="date" className="bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-600 text-sm shadow-inner" />
                <input type="time" className="bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-600 text-sm" />
              </div>
              <input type="text" placeholder="Lokasi Ruangan" className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-600 text-sm" />
            </div>
            <div className="flex gap-3 pt-2">
              <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 transition text-sm">Batal</button>
              <button className="flex-1 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 transition text-sm font-semibold">Simpan Event</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}