"use client";

import { useState } from "react";
import { Users, UserPlus, Search, Mail, Building2, X, Trash2, Edit2 } from "lucide-react";

const initialEmployees = [
  { id: "1", name: "Budi Santoso", email: "budi@office.com", dept: "IT Support", position: "Senior Staff" },
  { id: "2", name: "Siti Aminah", email: "siti@office.com", dept: "HRD", position: "Manager" },
  { id: "3", name: "Andi Wijaya", email: "andi@office.com", dept: "Marketing", position: "Staff" },
];

export default function EmployeesPage() {
  const [showModal, setShowModal] = useState(false);
  const [employees, setEmployees] = useState(initialEmployees);

  return (
    <div className="space-y-8 text-white">
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Daftar Karyawan</h1>
          <p className="text-slate-400 text-sm">Kelola data anggota dan hak akses rapat</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 transition text-sm font-medium"
        >
          <UserPlus size={18} /> Tambah Karyawan
        </button>
      </div>

      {/* STATS & SEARCH */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-800  p-2 rounded-2xl border border-slate-700 flex items-center gap-4">
          <div className="bg-blue-500/10 p-3 rounded-xl text-blue-400"><Users size={18}/></div>
          <div>
            <p className="text-xs text-slate-400 uppercase tracking-wider">Total Karyawan</p>
            <p className="text-md font-bold">{employees.length} Orang</p>
          </div>
        </div>
        <div className="md:col-span-2 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={13} />
          <input 
            type="text" 
            placeholder="Cari nama, email, atau departemen..." 
            className="w-full h-full bg-slate-800 border border-slate-700 rounded-2xl pl-12 pr-4 outline-none focus:border-blue-500 transition text-sm py-4"
          />
        </div>
      </div>

      {/* TABLE */}
      <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-900/50 text-slate-500 uppercase text-[10px] font-bold tracking-widest">
              <tr>
                <th className="px-6 py-4">Karyawan</th>
                <th className="px-6 py-4">Departemen</th>
                <th className="px-6 py-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {employees.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-700/30 transition group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center font-bold">
                        {emp.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium text-slate-200">{emp.name}</p>
                        <p className="text-xs text-slate-500 flex items-center gap-1">
                          <Mail size={12} /> {emp.email}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-slate-300">
                      <Building2 size={14} className="text-slate-500" />
                      <div>
                        <p>{emp.dept}</p>
                        <p className="text-[10px] text-slate-500 uppercase">{emp.position}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition">
                        <Edit2 size={16} />
                      </button>
                      <button className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL ADD EMPLOYEE */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 border border-slate-700 w-full max-w-lg rounded-3xl p-8 space-y-6 shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold">Tambah Karyawan Baru</h2>
                <p className="text-slate-400 text-xs">Masukkan detail informasi karyawan</p>
              </div>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white transition">
                <X size={24}/>
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs text-slate-400 ml-1">Nama Lengkap</label>
                <input type="text" placeholder="Masukkan nama..." className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500 text-sm" />
              </div>
              <div className="space-y-2">
                <label className="text-xs text-slate-400 ml-1">Email Kantor</label>
                <input type="email" placeholder="email@office.com" className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500 text-sm" />
              </div>
              <div className="space-y-2">
                <label className="text-xs text-slate-400 ml-1">Departemen</label>
                <select className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500 text-sm appearance-none">
                  <option>IT Support</option>
                  <option>HRD</option>
                  <option>Marketing</option>
                  <option>Finance</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs text-slate-400 ml-1">Jabatan</label>
                <input type="text" placeholder="Manager/Staff..." className="w-full bg-slate-900 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500 text-sm" />
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-slate-700">
              <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-3 rounded-xl bg-slate-700 hover:bg-slate-600 transition text-sm font-medium">
                Batal
              </button>
              <button className="flex-1 px-4 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 transition text-sm font-bold shadow-lg shadow-blue-900/20">
                Simpan Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}