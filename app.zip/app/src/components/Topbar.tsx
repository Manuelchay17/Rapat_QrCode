"use client";

import { Search, Bell, Plus } from "lucide-react";

export default function Topbar() {
  return (
    <header className="h-20 px-10 flex items-center justify-between
      bg-slate-900 border-b border-slate-800">

      {/* LEFT */}
      <div>
        <h1 className="text-xl font-semibold">Dashboard</h1>
        <p className="text-sm text-slate-400">
          Monitoring rapat & absensi
        </p>
      </div>

      {/* CENTER */}
      <div className="hidden md:flex items-center gap-2 bg-slate-800 px-4 py-2 rounded-xl">
        <Search size={16} className="text-slate-400" />
        <input
          className="bg-transparent outline-none text-sm text-slate-200 placeholder:text-slate-500 w-56"
          placeholder="Cari rapat atau peserta"
        />
      </div>

      {/* RIGHT */}
      <div className="flex items-center gap-5">
        <div className="text-xs text-emerald-400 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          Sistem Online
        </div>

        <button className="relative text-slate-400 hover:text-slate-200">
          <Bell size={20} />
        </button>

        <button className="flex items-center gap-2 px-4 py-2 rounded-xl
          bg-blue-600 hover:bg-blue-700 transition text-sm">
          <Plus size={16} />
          Buat Rapat
        </button>

        <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center font-semibold">
          A
        </div>
      </div>
    </header>
  );
}
